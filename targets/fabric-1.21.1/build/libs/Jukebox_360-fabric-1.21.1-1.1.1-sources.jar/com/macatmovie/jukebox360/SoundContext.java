package com.macatmovie.jukebox360;

import net.minecraft.class_1113;

/**
 * Thread-local bridge used to associate the currently-playing SoundInstance with
 * the Channel/Source being configured.
 */
public final class SoundContext {
    private SoundContext() {}

    public static final ThreadLocal<class_1113> CURRENT_SOUND = new ThreadLocal<>();
}
