package com.macatmovie.jukebox360.mixin;

import com.macatmovie.jukebox360.AudioSourceBlockWhitelist;
import com.macatmovie.jukebox360.Jukebox360Runtime;
import com.macatmovie.jukebox360.config.ClientConfig;
import com.macatmovie.jukebox360.mixinaccess.SourceTagAccessor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Consumer;
import net.minecraft.class_1113;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3419;
import net.minecraft.class_4224;
import net.minecraft.class_4235;

@Mixin(class_4235.class_4236.class)
public class ChannelSourceManagerMixin {
    private static final Logger LOG = LogManager.getLogger("Jukebox360");

    @Shadow class_4224 source;

    @Unique
    private static boolean isNoteBlock(class_1113 sound) {
        class_2960 id = sound.method_4775();
        if (id == null) return false;
        return id.method_12832().startsWith("block.note_block");
    }

    @Inject(method = "run(Ljava/util/function/Consumer;)V", at = @At("HEAD"))
    private void jukebox360$runHead(Consumer<class_4224> action, CallbackInfo ci) {
        class_1113 sound = com.macatmovie.jukebox360.SoundContext.CURRENT_SOUND.get();
        if (sound == null || this.source == null) {
            if (com.macatmovie.jukebox360.config.ClientConfig.debugLog()) {
                org.apache.logging.log4j.LogManager.getLogger("Jukebox360").info("[Jukebox360] SourceManager.run: no CURRENT_SOUND or no source");
            }
            return;
        }

        SourceTagAccessor acc = (SourceTagAccessor) (Object) this.source;

        boolean isRecords = sound.method_4774() == class_3419.field_15247;
        boolean isNote = isNoteBlock(sound);
        class_243 pos = new class_243(sound.method_4784(), sound.method_4779(), sound.method_4778());
        boolean whitelistBlock = !isRecords && !isNote
                && AudioSourceBlockWhitelist.matches(sound.method_4784(), sound.method_4779(), sound.method_4778());
        boolean target = isRecords || isNote || whitelistBlock;
        boolean sustained = isRecords || whitelistBlock;

        if (target) {
            acc.jukebox360$setAffected(true);
            acc.jukebox360$setRecords(sustained);
            acc.jukebox360$setWorldPos(pos);

            if (sustained) {
                Jukebox360Runtime.add(acc);
            } else {
                acc.jukebox360$applyProjectionTick();
                Jukebox360Runtime.remove(acc);
            }

            if (ClientConfig.debugLog()) {
                LOG.info("[Jukebox360] Tagged {} for {} pos={}",
                        isRecords ? "RECORDS" : (isNote ? "NOTE_BLOCK" : "WHITELIST_BLOCK"),
                        sound.method_4775(), pos);
            }
        } else {
            if (acc.jukebox360$isAffected() || acc.jukebox360$isRecords()) {
                acc.jukebox360$setAffected(false);
                acc.jukebox360$setRecords(false);
                acc.jukebox360$setWorldPos(null);
                Jukebox360Runtime.remove(acc);

                if (ClientConfig.debugLog()) {
                    LOG.info("[Jukebox360] Cleared tag for {} cat={}", sound.method_4775(), sound.method_4774());
                }
            }
        }
    }
}
