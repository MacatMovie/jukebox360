package com.macatmovie.jukebox360.mixinaccess;

import net.minecraft.class_243;

public interface SourceTagAccessor {
    void jukebox360$setRecords(boolean records);
    boolean jukebox360$isRecords();

    void jukebox360$setAffected(boolean affected);
    boolean jukebox360$isAffected();

    void jukebox360$setWorldPos(class_243 pos);
    class_243 jukebox360$getWorldPos();

    int jukebox360$getSourceId();

    void jukebox360$applyProjectionTick();
}
