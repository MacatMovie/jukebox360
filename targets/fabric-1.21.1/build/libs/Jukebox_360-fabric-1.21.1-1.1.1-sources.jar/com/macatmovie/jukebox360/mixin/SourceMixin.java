package com.macatmovie.jukebox360.mixin;

import com.macatmovie.jukebox360.Jukebox360Runtime;
import com.macatmovie.jukebox360.config.ClientConfig;
import com.macatmovie.jukebox360.mixinaccess.SourceTagAccessor;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4224;
import net.minecraft.class_746;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.openal.AL10;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4224.class)
public class SourceMixin implements SourceTagAccessor {
    private static final Logger LOG = LogManager.getLogger("Jukebox360");

    @Shadow private int pointer;

    @Unique private boolean jukebox360$records = false;
    @Unique private boolean jukebox360$affected = false;
    @Unique private class_243 jukebox360$worldPos = null;

    @Unique private static final double jukebox360$SMOOTHING_TIME_SECONDS = 0.075;
    @Unique private class_243 jukebox360$smoothedProjectedPos = null;
    @Unique private long jukebox360$lastProjectionNanos = 0L;

    @Override public void jukebox360$setRecords(boolean records) { this.jukebox360$records = records; }
    @Override public boolean jukebox360$isRecords() { return this.jukebox360$records; }

    @Override public void jukebox360$setAffected(boolean affected) {
        this.jukebox360$affected = affected;
        if (!affected) jukebox360$resetSmoothing();
    }
    @Override public boolean jukebox360$isAffected() { return this.jukebox360$affected; }

    @Override public void jukebox360$setWorldPos(class_243 pos) { this.jukebox360$worldPos = pos; }
    @Override public class_243 jukebox360$getWorldPos() { return this.jukebox360$worldPos; }

    @Override public int jukebox360$getSourceId() { return this.pointer; }

    @Override public void jukebox360$applyProjectionTick() { applyProjection(); }

    private void applyProjection() {
        if (!jukebox360$affected || jukebox360$worldPos == null) return;

        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null) return;

        class_243 ear = player.method_33571();
        class_243 toWorld = jukebox360$worldPos.method_1020(ear);
        double dist = toWorld.method_1033();
        if (dist < 1e-6) return;

        class_243 dirWorld = toWorld.method_1029();

        class_243 look = player.method_5828(1.0F);
        if (look.method_1027() < 1e-6) look = new class_243(0, 0, 1);
        class_243 dirLook = look.method_1029();

        double blend = ClientConfig.BLEND;
        class_243 blendedDir = dirWorld.method_1021(1.0 - blend).method_1019(dirLook.method_1021(blend));
        if (blendedDir.method_1027() < 1e-10) blendedDir = dirWorld;
        blendedDir = blendedDir.method_1029();

        class_243 out = ear.method_1019(blendedDir.method_1021(dist));

        out = jukebox360$smoothProjectedPosition(out);

        AL10.alSourcei(this.pointer, AL10.AL_SOURCE_RELATIVE, AL10.AL_FALSE);
        AL10.alSource3f(this.pointer, AL10.AL_POSITION, (float) out.field_1352, (float) out.field_1351, (float) out.field_1350);

        if (ClientConfig.DEBUG_LOG) {
            LOG.info("[Jukebox360] Project srcId={} kind={} blend={} dist={}",
                    this.pointer,
                    this.jukebox360$records ? "RECORDS" : "NOTE_BLOCK",
                    String.format("%.2f", blend),
                    String.format("%.2f", dist));
        }
    }

    @Unique
    private class_243 jukebox360$smoothProjectedPosition(class_243 target) {
        long now = System.nanoTime();

        // First update (or a long pause/source reuse) should snap immediately rather
        // than spending several ticks catching up from an obsolete position.
        if (this.jukebox360$smoothedProjectedPos == null || this.jukebox360$lastProjectionNanos == 0L) {
            this.jukebox360$smoothedProjectedPos = target;
            this.jukebox360$lastProjectionNanos = now;
            return target;
        }

        double dt = (now - this.jukebox360$lastProjectionNanos) / 1_000_000_000.0;
        this.jukebox360$lastProjectionNanos = now;

        if (dt <= 0.0 || dt > 0.5) {
            this.jukebox360$smoothedProjectedPos = target;
            return target;
        }

        // Exponential smoothing is frame-rate/tick-rate independent. With the
        // current 20 Hz update path and a 75 ms time constant, each normal tick
        // moves about 49% toward the new projected position.
        double alpha = 1.0 - Math.exp(-dt / jukebox360$SMOOTHING_TIME_SECONDS);
        alpha = Math.max(0.0, Math.min(1.0, alpha));

        class_243 current = this.jukebox360$smoothedProjectedPos;
        class_243 smoothed = current.method_1019(target.method_1020(current).method_1021(alpha));
        this.jukebox360$smoothedProjectedPos = smoothed;
        return smoothed;
    }

    @Unique
    private void jukebox360$resetSmoothing() {
        this.jukebox360$smoothedProjectedPos = null;
        this.jukebox360$lastProjectionNanos = 0L;
    }

    @Inject(method = "stop", at = @At("HEAD"))
    private void jukebox360$stop(CallbackInfo ci) {
        Jukebox360Runtime.remove(this);
        this.jukebox360$affected = false;
        this.jukebox360$records = false;
        this.jukebox360$worldPos = null;
        jukebox360$resetSmoothing();
    }
}
