package com.macatmovie.jukebox360.client.gui;

import com.macatmovie.jukebox360.config.ClientConfig;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class BlockWhitelistScreen extends class_437 {
    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Config screens are standalone screens; never leave the previous UI visible underneath.
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xF0101010);
        super.method_25394(context, mouseX, mouseY, delta);
    }


    private static final int PAGE_SIZE = 5;
    private final class_437 parent;
    private final List<String> entries;
    private final int page;
    private class_342 input;

    public BlockWhitelistScreen(class_437 parent) { this(parent, ClientConfig.blockWhitelist(), 0); }
    private BlockWhitelistScreen(class_437 parent, List<String> entries, int page) {
        super(class_2561.method_43470("Jukebox 360 Audio Source Blocks"));
        this.parent = parent;
        this.entries = new ArrayList<>(entries);
        this.page = Math.max(0, page);
    }

    @Override
    protected void method_25426() {
        int x = this.field_22789 / 2 - 150;
        int y = 28;
        input = new class_342(this.field_22793, x, y, 220, 20, class_2561.method_43470("modid:block"));
        input.method_1880(160);
        this.method_37063(input);
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Add"), b -> addEntry())
                .method_46434(x + 226, y, 74, 20).method_46431());

        int start = page * PAGE_SIZE;
        int end = Math.min(entries.size(), start + PAGE_SIZE);
        for (int i = start; i < end; i++) {
            final int index = i;
            String id = entries.get(i);
            this.method_37063(class_4185.method_46430(class_2561.method_43470("Remove: " + id), b -> removeEntry(index))
                    .method_46434(x, y + 30 + (i - start) * 24, 300, 20).method_46431());
        }

        int navY = y + 30 + PAGE_SIZE * 24 + 4;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("< Previous"), b -> openPage(Math.max(0, page - 1)))
                .method_46434(x, navY, 96, 20).method_46431()).field_22763 = page > 0;
        int maxPage = entries.isEmpty() ? 0 : (entries.size() - 1) / PAGE_SIZE;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Next >"), b -> openPage(Math.min(maxPage, page + 1)))
                .method_46434(x + 102, navY, 96, 20).method_46431()).field_22763 = page < maxPage;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reset List"), b ->
                this.field_22787.method_1507(new BlockWhitelistScreen(parent, ClientConfig.DEFAULT_BLOCK_WHITELIST, 0)))
                .method_46434(x + 204, navY, 96, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), b -> saveAndClose())
                .method_46434(this.field_22789 / 2 - 75, navY + 28, 150, 20).method_46431());
    }

    private void addEntry() {
        String id = input.method_1882().trim().toLowerCase();
        if (!ClientConfig.isValidId(id) || entries.contains(id)) return;
        entries.add(id);
        this.field_22787.method_1507(new BlockWhitelistScreen(parent, entries, (entries.size() - 1) / PAGE_SIZE));
    }
    private void removeEntry(int index) {
        if (index >= 0 && index < entries.size()) entries.remove(index);
        int maxPage = entries.isEmpty() ? 0 : (entries.size() - 1) / PAGE_SIZE;
        this.field_22787.method_1507(new BlockWhitelistScreen(parent, entries, Math.min(page, maxPage)));
    }
    private void openPage(int next) { this.field_22787.method_1507(new BlockWhitelistScreen(parent, entries, next)); }
    private void saveAndClose() { ClientConfig.setBlockWhitelist(entries); ClientConfig.save(); this.field_22787.method_1507(parent); }
    @Override public void method_25419() { saveAndClose(); }
}
