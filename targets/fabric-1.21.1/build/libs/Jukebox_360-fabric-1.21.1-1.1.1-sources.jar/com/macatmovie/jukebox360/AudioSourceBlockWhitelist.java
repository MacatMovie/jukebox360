package com.macatmovie.jukebox360;

import com.macatmovie.jukebox360.config.ClientConfig;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_7923;

public final class AudioSourceBlockWhitelist {
    private AudioSourceBlockWhitelist() {}

    public static boolean matches(double x, double y, double z) {
        try {
            class_310 mc = class_310.method_1551();
            if (mc.field_1687 == null || ClientConfig.blockWhitelist().isEmpty()) return false;
            class_2338 pos = class_2338.method_49637(x, y, z);
            var block = mc.field_1687.method_8320(pos).method_26204();
            var id = class_7923.field_41175.method_10221(block);
            return id != null && ClientConfig.isBlockWhitelisted(id.toString());
        } catch (Throwable ignored) {
            return false;
        }
    }
}
