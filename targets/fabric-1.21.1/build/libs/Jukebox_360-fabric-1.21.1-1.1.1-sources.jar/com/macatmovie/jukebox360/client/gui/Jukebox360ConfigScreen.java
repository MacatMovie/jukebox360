package com.macatmovie.jukebox360.client.gui;

import com.macatmovie.jukebox360.config.ClientConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class Jukebox360ConfigScreen extends class_437 {
    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Config screens are standalone screens; never leave the previous UI visible underneath.
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xF0101010);
        super.method_25394(context, mouseX, mouseY, delta);
    }


    private final class_437 parent;
    private BlendSlider blendSlider;
    private class_4185 debugButton;
    private class_4185 whitelistButton;

    public Jukebox360ConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Jukebox 360 Configuration"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int x = this.field_22789 / 2 - 100;
        int y = Math.max(35, this.field_22790 / 2 - 72);

        blendSlider = this.method_37063(new BlendSlider(x, y, 200, 20));

        debugButton = this.method_37063(class_4185.method_46430(debugText(), b -> {
            ClientConfig.setDebugLog(!ClientConfig.debugLog());
            b.method_25355(debugText());
        }).method_46434(x, y + 26, 200, 20).method_46431());

        whitelistButton = this.method_37063(class_4185.method_46430(whitelistText(), b ->
                this.field_22787.method_1507(new BlockWhitelistScreen(this)))
                .method_46434(x, y + 52, 200, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reset to Defaults"), b -> {
            ClientConfig.resetDefaults();
            ClientConfig.save();
            blendSlider.syncFromConfig();
            debugButton.method_25355(debugText());
            whitelistButton.method_25355(whitelistText());
        }).method_46434(x, y + 84, 98, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), b -> closeAndSave())
                .method_46434(x + 102, y + 84, 98, 20).method_46431());
    }

    private class_2561 debugText() { return class_2561.method_43470("Debug Logging: " + (ClientConfig.debugLog() ? "ON" : "OFF")); }
    private class_2561 whitelistText() { return class_2561.method_43470("Audio Source Block Whitelist (" + ClientConfig.blockWhitelist().size() + ")..."); }

    private void closeAndSave() {
        ClientConfig.save();
        this.field_22787.method_1507(parent);
    }

    @Override public void method_25419() { closeAndSave(); }

    private static final class BlendSlider extends class_357 {
        private BlendSlider(int x, int y, int width, int height) {
            super(x, y, width, height, class_2561.method_43470(""), ClientConfig.blend());
            method_25346();
        }

        @Override
        protected void method_25346() {
            method_25355(class_2561.method_43470("Anchor Blend: " + Math.round(this.field_22753 * 100.0D) + "%"));
        }

        @Override
        protected void method_25344() {
            double snapped = Math.round(this.field_22753 * 100.0D) / 100.0D;
            this.field_22753 = snapped;
            ClientConfig.setBlend(snapped);
            method_25346();
        }

        private void syncFromConfig() {
            this.field_22753 = ClientConfig.blend();
            method_25346();
        }
    }
}
